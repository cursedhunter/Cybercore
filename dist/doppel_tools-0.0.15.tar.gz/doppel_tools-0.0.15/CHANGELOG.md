# Change Log

## [0.0.15] 2025-02-12

* Rename project
* Interface mapping per host ([#3][i3])
* Removed generate-topology app

[i3]: https://github.com/arista-eosplus/doppel-tools/pull/3

## [0.0.14] 2025-01-10

* Fix deepmerge: added strategies to frozen types tuple and frozenset

## [0.0.13] 2025-01-10

* Refactor split strategy. Implemented two different split strategies: spread and disjoint
* generate_anta_inventory.py: fix error handling hostnames from ansible inventory

## [0.0.1] 2024-06-12

Initial release
