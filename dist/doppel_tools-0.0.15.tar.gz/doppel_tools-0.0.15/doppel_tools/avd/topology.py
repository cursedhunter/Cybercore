"""doppel_tools.avd.topology."""

from pathlib import Path
from typing import Optional

from doppel_tools.ceos.mac_generator import ARISTA_OUI_1, MACGenerator
from doppel_tools.model.avd import NodeStructuredConfig
from doppel_tools.model.topology import Node, Topology


def load_topology(
    nodes: list[str],
    structured_configs_path: Path,
    mac_generator: MACGenerator = MACGenerator(mac_oui=ARISTA_OUI_1),
    remote_nodes: Optional[set[str]] = None,
) -> Topology:
    """Load a topology from structured config files."""
    if len(nodes) == 0:
        return Topology(nodes={})

    return Topology(
        nodes={
            node_structured_config.hostname: Node(
                name=node_structured_config.hostname,
                system_mac_address=node_structured_config.maybe_system_mac_address
                or mac_generator.generate_mac_address(seed=node_structured_config.hostname.encode("utf-8")),
                management_interface=node_structured_config.oob_management_interface,
                physical_interfaces=node_structured_config.ethernet_interfaces,
            )
            for node_structured_config in (
                NodeStructuredConfig.load(structured_config_path=Path(structured_configs_path / node).with_suffix(".yml"))
                for node in nodes
            )
        },
        remote_nodes=remote_nodes or set(),
    )
