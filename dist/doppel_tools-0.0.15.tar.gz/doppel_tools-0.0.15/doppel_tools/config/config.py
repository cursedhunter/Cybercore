"""Runtime config module."""

from pathlib import Path
from typing import Any, Optional

import yaml
from frozendict import deepfreeze, frozendict

from doppel_tools.utils.deepmerge import frozendict_merger

CONTAINERLAB_BASE_TOPOLOGY_KEY = "containerlab_base_topology"

CONFIG_DEFAULTS = deepfreeze(
    {
        CONTAINERLAB_BASE_TOPOLOGY_KEY: {
            "name": "clab_topology",
        },
    }
)

runtime_config: frozendict = CONFIG_DEFAULTS


def init_runtime_config(
    config_defaults: frozendict[str, Any] = CONFIG_DEFAULTS, config_path: Optional[Path] = None
) -> frozendict:
    """Initialize runtime config."""
    global runtime_config  # pylint: disable=global-statement

    if config_path is None:
        runtime_config = config_defaults
        return runtime_config

    with open(config_path, "r", encoding="utf-8") as fd:
        config_from_file = deepfreeze(yaml.safe_load(fd) or {})

    runtime_config = frozendict_merger.merge(
        config_defaults,
        config_from_file,
    )

    return runtime_config


def get_runtime_config() -> frozendict:
    """Get runtime config."""
    return runtime_config
