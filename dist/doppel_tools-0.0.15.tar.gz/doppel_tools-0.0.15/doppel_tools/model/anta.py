"""doppel_tools.model.anta."""

from dataclasses import dataclass


@dataclass(frozen=True)
class AntaInventoryHost:
    """Host entry of AntaInventoryInput."""

    host: str
    name: str
