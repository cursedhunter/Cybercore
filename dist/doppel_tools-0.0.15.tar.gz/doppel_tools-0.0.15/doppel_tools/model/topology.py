"""doppel_tools.model.topology."""

from dataclasses import dataclass, field

from doppel_tools.model.avd import Interface, ManagementInterface


@dataclass(frozen=True, order=True)
class LinkEndpoint:
    """LinkEndpoint dataclass."""

    node: str
    interface: str


@dataclass(frozen=True)
class Link:
    """Link dataclass."""

    endpoint_a: LinkEndpoint
    endpoint_b: LinkEndpoint

    def as_frozenset(self):
        """Pack endpoints in a frozenset."""
        return frozenset([self.endpoint_a, self.endpoint_b])

    def __eq__(self, other):
        """Compare frozensets."""
        return self.as_frozenset() == other.as_frozenset()

    def __hash__(self):
        """Hash from frozenset."""
        return hash(self.as_frozenset())


@dataclass(frozen=True)
class Node:
    """Node dataclass."""

    name: str
    system_mac_address: str
    management_interface: ManagementInterface
    physical_interfaces: tuple[Interface, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class Topology:
    """Topology dataclass."""

    nodes: dict[str, Node]
    remote_nodes: set[str] = field(default_factory=set)
    links: tuple[Link, ...] = field(init=False)
    "links between nodes. Calculated from node physical_interfaces peers contained in local nodes."
    remote_links: tuple[Link, ...] = field(init=False)
    "links from nodes to remote nodes. Calculated from node physical_interfaces peers contained in remote nodes."
    endpoint_links: tuple[Link, ...] = field(init=False)
    "links from nodes to hosts/servers. Calculated from node physical_interfaces peers not contained in local/remote nodes."

    def __post_init__(self):
        """Post init: calculate links."""
        object.__setattr__(  # links assignment https://docs.python.org/3/library/dataclasses.html#frozen-instances
            self,
            "links",
            tuple(
                {  # ordered set
                    Link(
                        endpoint_a=LinkEndpoint(node=node.name, interface=interface.name),
                        endpoint_b=LinkEndpoint(node=interface.peer.peer_name, interface=interface.peer.peer_interface_name),
                    ): None
                    for node in self.nodes.values()
                    for interface in node.physical_interfaces
                    if interface.peer and interface.peer.peer_name in self.nodes
                }.keys()
            ),
        )
        object.__setattr__(
            self,
            "remote_links",
            tuple(
                {  # ordered set
                    Link(
                        endpoint_a=LinkEndpoint(node=node.name, interface=interface.name),
                        endpoint_b=LinkEndpoint(node=interface.peer.peer_name, interface=interface.peer.peer_interface_name),
                    ): None
                    for node in self.nodes.values()
                    for interface in node.physical_interfaces
                    if interface.peer and interface.peer.peer_name in self.remote_nodes
                }.keys()
            ),
        )
        object.__setattr__(
            self,
            "endpoint_links",
            tuple(
                {  # ordered set
                    Link(
                        endpoint_a=LinkEndpoint(node=node.name, interface=interface.name),
                        endpoint_b=LinkEndpoint(node=interface.peer.peer_name, interface=interface.peer.peer_interface_name)
                        if interface.peer
                        else LinkEndpoint(node="unknown", interface="unknown"),
                    ): None
                    for node in self.nodes.values()
                    for interface in node.physical_interfaces
                    if interface.peer is None
                    or (interface.peer.peer_name not in self.nodes and interface.peer.peer_name not in self.remote_nodes)
                }.keys()
            ),
        )
