"""doppel_tools.model."""
