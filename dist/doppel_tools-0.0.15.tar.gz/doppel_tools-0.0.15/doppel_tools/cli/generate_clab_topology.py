"""doppel_tools.cli.generate_clab_topology."""

import json
import logging
import sys
from collections.abc import Iterable
from pathlib import Path
from typing import Annotated, Optional

import typer
import yaml
from frozendict import deepfreeze, frozendict
from natsort import natsorted

from doppel_tools.ansible.inventory import Inventory
from doppel_tools.avd.topology import (
    load_topology,
)
from doppel_tools.ceos.interface import interface_to_device_name
from doppel_tools.ceos.vni_generator import VNIGenerator
from doppel_tools.config.config import (
    CONFIG_DEFAULTS,
    CONTAINERLAB_BASE_TOPOLOGY_KEY,
    init_runtime_config,
)
from doppel_tools.model.topology import Link, Node, Topology
from doppel_tools.utils.deepmerge import frozendict_merger

app = typer.Typer()
logger = logging.getLogger()

# Add frozendict representer
yaml.representer.SafeRepresenter.add_representer(
    frozendict, lambda self, data: self.represent_mapping("tag:yaml.org,2002:map", dict(data))
)

CEOS_CONFIG_BASE_PATH = "ceos_config"
CEOS_CONFIG_SYSTEM_MAC_ADDR_ENV = "SYSTEMMACADDR"
CEOS_INTERFACE_MAPPING_BASE_PATH = "ceos_interface_map"


def get_clab_nodes(nodes: Iterable[Node]) -> dict:
    """Get clab nodes."""
    return {
        f"{node.name}": (
            {
                "kind": "ceos",
                "binds": [
                    f"configs/{node.name}.cfg:/mnt/flash/startup-config:ro",
                    f"{CEOS_CONFIG_BASE_PATH}/{node.name}:/mnt/flash/ceos-config:ro",
                    f"{CEOS_INTERFACE_MAPPING_BASE_PATH}/{node.name}_EosIntfMapping.json:/mnt/flash/EosIntfMapping.json:ro",
                ],
                "mgmt-ipv4": node.management_interface.ip_address,
            }
        )
        for node in nodes
    }


def get_clab_links(links: Iterable[Link], endpoint_delim: str = ":") -> list:
    """Get clab links with natural sort on first endpoint."""
    return [
        {
            "endpoints": [
                endpoint_delim.join([link.endpoint_a.node, interface_to_device_name(link.endpoint_a.interface)]),
                endpoint_delim.join([link.endpoint_b.node, interface_to_device_name(link.endpoint_b.interface)]),
            ]
        }
        for link in natsorted(links, key=lambda link: link.endpoint_a)
    ]


def get_clab_host_links(links: Iterable[Link], endpoint_delim: str = ":") -> list:
    """Get clab host links with natural sort on first endpoint."""
    return [
        {
            "endpoints": [
                endpoint_delim.join([link.endpoint_a.node, interface_to_device_name(link.endpoint_a.interface)]),
                endpoint_delim.join(["host", f"{link.endpoint_b.node}_{link.endpoint_b.interface}"]),
            ]
        }
        for link in natsorted(links, key=lambda link: link.endpoint_a)
    ]


def get_clab_remote_links(
    links: Iterable[Link],
    node_to_host: frozendict[str, str],
    vni_generator: VNIGenerator,
    vxlan_mtu: int,
    vxlan_port: int,
) -> list:
    """Get clab remote links with natural sort on first endpoint."""
    return [
        {
            "type": "vxlan",
            "endpoint": {
                "node": link.endpoint_a.node,
                "interface": interface_to_device_name(link.endpoint_a.interface),
            },
            "remote": node_to_host[link.endpoint_b.node],
            "vni": vni_generator.generate_vni(link),
            "udp-port": vxlan_port,
            "mtu": vxlan_mtu,
        }
        for link in natsorted(links, key=lambda link: link.endpoint_a)
    ]


def generate_clab_topology(
    topology: Topology,
    name: str,
    clab_base_topology: frozendict,
) -> frozendict:
    """Generate clab topology."""
    return frozendict_merger.merge(
        clab_base_topology,
        deepfreeze(
            {
                "name": name,
                "topology": {
                    "nodes": get_clab_nodes(topology.nodes.values()),
                    "links": get_clab_links(topology.links) + get_clab_host_links(topology.endpoint_links),
                },
            }
        ),
    )


def generate_clab_sub_topology(
    topology: Topology,
    name: str,
    clab_base_topology: frozendict,
    node_to_host: frozendict[str, str],
    vni_generator: VNIGenerator,
    vxlan_mtu: int,
    vxlan_port: int,
) -> frozendict:
    """Generate clab topology."""
    return frozendict_merger.merge(
        generate_clab_topology(topology, name, clab_base_topology),
        deepfreeze(
            {
                "topology": {
                    "links": get_clab_remote_links(topology.remote_links, node_to_host, vni_generator, vxlan_mtu, vxlan_port),
                },
            }
        ),
    )


def generate_eos_interface_mapping(node: Node) -> dict:
    """Generate EOS interface mapping file contents."""
    return {
        "ManagementIntf": {
            "eth0": node.management_interface.name,
        },
        "EthernetIntf": {
            interface_to_device_name(physical_interface.name): physical_interface.name
            for physical_interface in natsorted(node.physical_interfaces, key=lambda i: i.name)
        },
    }


def dump_eos_interface_map(output_path: Path, topology: Topology):
    """Dump EOS interface mapping file contents."""
    ceos_interface_mapping_path = output_path / CEOS_INTERFACE_MAPPING_BASE_PATH
    ceos_interface_mapping_path.mkdir(parents=True, exist_ok=True)
    for node in topology.nodes.values():
        eos_intf_mapping = generate_eos_interface_mapping(node=node)
        with open(ceos_interface_mapping_path / f"{node.name}_EosIntfMapping.json", mode="w", encoding="utf8") as fd:
            json.dump(eos_intf_mapping, fd, indent=2)


def dump_ceos_config(output_path: Path, topology: Topology):
    """Dump CEOS configuration file contents."""
    ceos_config_path = output_path / CEOS_CONFIG_BASE_PATH
    ceos_config_path.mkdir(parents=True, exist_ok=True)
    for node in topology.nodes.values():
        with open(ceos_config_path / node.name, mode="w", encoding="utf8") as fd:
            fd.write(f"{CEOS_CONFIG_SYSTEM_MAC_ADDR_ENV}={node.system_mac_address}\n")


@app.command()
def main(
    inventory_path: Annotated[
        Path,
        typer.Option(
            "--inventory-path",
            "-i",
            exists=True,
            file_okay=True,
            dir_okay=False,
            writable=False,
            readable=True,
            resolve_path=True,
        ),
    ],
    limit: Annotated[str, typer.Option("--limit")] = "all,!cv*",
    output_path: Annotated[
        Path,
        typer.Option(
            "--output-path",
            "-o",
            file_okay=False,
            dir_okay=True,
            writable=True,
            resolve_path=True,
        ),
    ] = Path("clab"),
    config_path: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            exists=False,
            file_okay=True,
            dir_okay=False,
            writable=False,
            readable=True,
            resolve_path=True,
        ),
    ] = None,
    host_node_map_path: Annotated[
        Optional[Path],
        typer.Option(
            "--host-node-map-path",
            "-m",
            exists=True,
            file_okay=True,
            dir_okay=False,
            writable=False,
            readable=True,
            resolve_path=True,
        ),
    ] = None,
    vxlan_mtu: Annotated[int, typer.Option("--vxlan-mtu")] = 1600,
    vxlan_port: Annotated[int, typer.Option("--vxlan-port")] = 14789,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
):
    """Main function."""
    logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO)

    logger.info("inventory_path: %s", inventory_path)
    logger.info("host_node_map_path: %s", host_node_map_path)
    logger.info("output_path: %s", output_path)
    logger.info("config_path: %s", config_path)

    config = init_runtime_config(config_defaults=CONFIG_DEFAULTS, config_path=config_path)

    inventory = Inventory(inventory_path=inventory_path)
    inventory_base_path = inventory_path.parent

    all_nodes = inventory.get_hosts(pattern=limit)
    all_node_names = [str(host.name) for host in all_nodes]
    if len(all_node_names) == 0:
        logger.error("No nodes matched pattern=%s", limit)
        sys.exit(1)

    # load topology
    topology = load_topology(
        nodes=all_node_names,
        structured_configs_path=inventory_base_path / "intended" / "structured_configs",
    )

    clab_topology_name = config[CONTAINERLAB_BASE_TOPOLOGY_KEY]["name"]
    clab_topology = generate_clab_topology(
        topology=topology,
        name=clab_topology_name,
        clab_base_topology=config[CONTAINERLAB_BASE_TOPOLOGY_KEY],
    )

    output_path.mkdir(parents=True, exist_ok=True)
    with open(output_path / f"{clab_topology_name}.clab.yml", mode="w", encoding="utf8") as fd:
        yaml.safe_dump(clab_topology, fd, sort_keys=False)

    dump_ceos_config(output_path, topology)
    dump_eos_interface_map(output_path, topology)

    # Generate sub topologies
    if host_node_map_path is not None:
        with open(host_node_map_path, mode="r", encoding="utf8") as fd:
            host_to_node = deepfreeze(yaml.safe_load(fd))
        node_to_host = frozendict({node: host for host, nodes in host_to_node.items() for node in nodes})

        vni_generator = VNIGenerator()

        for host, node_names in host_to_node.items():
            if not set(node_names).issubset(all_node_names):
                logger.error(
                    "% host mapping contains nodes not present in the topology: %s",
                    host,
                    set(node_names) - set(all_node_names),
                )
                sys.exit(1)

            sub_topology = Topology(
                nodes={k: v for k, v in topology.nodes.items() if k in node_names},
                remote_nodes=set(all_node_names) - set(node_names),
            )

            clab_sub_topology_name = f"{clab_topology_name}_{host}"
            clab_sub_topology = generate_clab_sub_topology(
                topology=sub_topology,
                name=clab_sub_topology_name,
                clab_base_topology=config[CONTAINERLAB_BASE_TOPOLOGY_KEY],
                node_to_host=node_to_host,
                vni_generator=vni_generator,
                vxlan_mtu=vxlan_mtu,
                vxlan_port=vxlan_port,
            )

            with open(output_path / f"{host}.clab.yml", mode="w", encoding="utf8") as fd:
                yaml.safe_dump(clab_sub_topology, fd, sort_keys=False)


if __name__ == "__main__":
    typer.run(main)
