"""doppel_tools.cli.split_topology.

Given an AVD topology and a list of hosts distributes the topology nodes
between the hosts. The current strategy to distribute the hosts is as
follows:

1. group_nodes()
    - This function groups nodes into groups where the nodes of each group is not directly
        connected to any other node in the group, i.e. super spines and leafs have no interfaces
        directly connected. This ensures uniformity such that all links in subtopologies
        will be VxLAN links.
2. assign_hosts()
    - This function assignes nodes to each host. All nodes assigned to a host must be from the
        same group defined by group_nodes(). Each host is also assigned only MAX_INSTANCES_PER_HOST
        number of nodes.
"""

import logging
import sys
from pathlib import Path
from typing import Annotated, List

import typer
import yaml

from doppel_tools.ansible.inventory import Inventory
from doppel_tools.avd.topology import load_topology
from doppel_tools.topology.split_strategy import (
    SplitStrategyEnum,
    get_split_strategies,
)

# GLOBAL VARIABLES
app = typer.Typer()
logger = logging.getLogger()


@app.command()
def main(
    inventory_path: Annotated[
        Path,
        typer.Option(
            "--inventory-path",
            "-i",
            exists=True,
            file_okay=True,
            dir_okay=False,
            writable=False,
            readable=True,
            resolve_path=True,
        ),
    ],
    hosts: Annotated[List[str], typer.Argument(help="List of hosts to distribute the topology.")],
    strategy: Annotated[SplitStrategyEnum, typer.Option(help="Split strategy to use.")] = SplitStrategyEnum.DISJOINT,
    limit: Annotated[str, typer.Option("--limit")] = "all,!cv*",
    output_path: Annotated[
        Path,
        typer.Option(
            "--output-path",
            "-o",
            file_okay=True,
            dir_okay=False,
            writable=True,
            resolve_path=True,
        ),
    ] = Path("host_mapping.yml"),
    max_nodes_per_host: Annotated[int, typer.Option(help="Max number of nodes per host.")] = 40,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
):
    """Main function."""
    logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO)

    logger.info("inventory_path: %s", inventory_path)
    logger.info("hosts: %s", hosts)
    logger.info("strategy: %s", strategy)
    logger.info("limit: %s", limit)
    logger.info("output_path: %s", output_path)

    inventory = Inventory(inventory_path=inventory_path)
    inventory_base_path = inventory_path.parent

    all_nodes = inventory.get_hosts(pattern=limit)
    all_node_names = [str(host.name) for host in all_nodes]
    if len(all_node_names) == 0:
        logger.error("No nodes matched pattern=%s", limit)
        sys.exit(1)

    # load topology
    topology = load_topology(
        nodes=all_node_names,
        structured_configs_path=inventory_base_path / "intended" / "structured_configs",
    )

    split_strategy_cls = get_split_strategies()[strategy]
    split_strategy = split_strategy_cls(max_nodes_per_host=max_nodes_per_host)

    host_mapping = split_strategy.split(hosts=hosts, topology=topology)
    with open(output_path, "w", encoding="utf-8") as fd:
        yaml.safe_dump(host_mapping, fd, indent=2)


if __name__ == "__main__":
    typer.run(main)
