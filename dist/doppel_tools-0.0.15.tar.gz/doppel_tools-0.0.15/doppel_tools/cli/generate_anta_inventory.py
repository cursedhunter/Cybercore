"""doppel_tools.cli.generate_anta_inventory."""

import logging
from collections.abc import Iterator
from dataclasses import asdict
from pathlib import Path
from typing import Annotated, Optional

import typer
import yaml
from ansible.inventory.host import Host  # type: ignore

from doppel_tools.ansible.inventory import Inventory
from doppel_tools.model.anta import AntaInventoryHost
from doppel_tools.model.avd import NodeStructuredConfig

app = typer.Typer()
logger = logging.getLogger()


def generate_anta_inventory_hosts(
    hosts: list[Host], structured_config_path: Path, management_interface: Optional[str]
) -> Iterator[AntaInventoryHost]:
    """Generate anta inventory host items per inventory host."""
    for host in hosts:
        hostname = str(host.name)
        inventory_host = hostname

        if management_interface:
            host_structured_config_path = Path(structured_config_path / hostname).with_suffix(".yml")
            if not host_structured_config_path.exists():
                logger.info(
                    "%s found in inventory but structured config not present (%s). Skipping",
                    hostname,
                    host_structured_config_path,
                )
                continue
            structured_config = NodeStructuredConfig.load(structured_config_path=host_structured_config_path)
            inventory_host = structured_config.get_management_interface(management_interface_name=management_interface).ip_address

        yield AntaInventoryHost(host=inventory_host, name=hostname)


def generate_anta_inventory(
    inventory_path: Path,
    anta_inventory_path: Path,
    limit: str,
    management_interface: Optional[str],
):
    """Generate Anta Inventory."""
    inventory = Inventory(inventory_path=inventory_path)
    inventory_base_path = inventory_path.parent

    anta_inventory_path.parent.mkdir(parents=True, exist_ok=True)
    with open(anta_inventory_path, mode="w", encoding="utf8") as fd:
        yaml.safe_dump(
            {
                "anta_inventory": {
                    "hosts": [
                        asdict(anta_inventory_host)
                        for anta_inventory_host in generate_anta_inventory_hosts(
                            inventory.get_hosts(pattern=limit),
                            Path(inventory_base_path / "intended" / "structured_configs"),
                            management_interface=management_interface,
                        )
                    ]
                }
            },
            fd,
        )


@app.command()
def main(
    inventory_path: Annotated[
        Path,
        typer.Option(
            "--inventory-path",
            "-i",
            exists=True,
            file_okay=True,
            dir_okay=False,
            writable=False,
            readable=True,
            resolve_path=True,
        ),
    ],
    limit: Annotated[str, typer.Option("--limit")] = "all,!cv*",
    output_path: Annotated[
        Path,
        typer.Option(
            "--output-path",
            "-o",
            file_okay=True,
            dir_okay=False,
            writable=True,
            resolve_path=True,
        ),
    ] = Path("anta", "inventory.yml"),
    management_interface: Annotated[
        Optional[str],
        typer.Option(
            "--mgmt-interface", help="If provided, use management interface IP as host, otherwise host will be the node name"
        ),
    ] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
):
    """Main function."""
    logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO)

    logger.info("inventory_path: %s", inventory_path)
    logger.info("output_path: %s", output_path)
    logger.info("limit: %s", limit)
    logger.info("management_interface: %s", management_interface)

    generate_anta_inventory(
        inventory_path=inventory_path,
        anta_inventory_path=output_path,
        limit=limit,
        management_interface=management_interface,
    )


if __name__ == "__main__":
    typer.run(main)
