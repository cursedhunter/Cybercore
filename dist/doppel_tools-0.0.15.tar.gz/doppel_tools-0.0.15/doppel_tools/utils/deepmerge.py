"""doppel_tools.utils.deepmerge."""

from deepmerge import Merger  # type: ignore
from frozendict import frozendict


def frozendict_strategy_merge(config: Merger, path: list, base: frozendict, nxt: frozendict) -> frozendict:
    """Merge frozen dicts."""
    for k, v in nxt.items():
        base = base.set(k, v) if k not in base else base.set(k, config.value_strategy(path + [k], base[k], v))
    return base


def tuple_strategy_append(_config: Merger, _path: list, base: tuple, nxt: tuple) -> tuple:
    """Append nxt to base."""
    return base + nxt


def frozenset_strategy_union(_config: Merger, _path: list, base: frozenset, nxt: frozenset) -> frozenset:
    """Join nxt to base."""
    return base | nxt


frozendict_merger = Merger(
    # pass in a list of tuple, with the
    # strategies you are looking to apply
    # to each type.
    [
        (frozendict, frozendict_strategy_merge),
        (tuple, tuple_strategy_append),
        (frozenset, frozenset_strategy_union),
    ],
    # next, choose the fallback strategies,
    # applied to all other types:
    ["override"],
    # finally, choose the strategies in
    # the case where the types conflict:
    ["override"],
)
