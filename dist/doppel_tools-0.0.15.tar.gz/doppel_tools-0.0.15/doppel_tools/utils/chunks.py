"""Chunks."""

from typing import Iterator, List, TypeVar

V = TypeVar("V")


def chunks(lst: List[V], size: int) -> Iterator[List[V]]:
    """Yield successive n-sized chunks from lst."""
    for index in range(0, len(lst), size):
        yield lst[index : index + size]
