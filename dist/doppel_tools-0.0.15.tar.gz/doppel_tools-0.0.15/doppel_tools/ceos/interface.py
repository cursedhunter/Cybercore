"""doppel_tools.ceos.interface."""

import re

ETHERNET_PREFIX = "Ethernet"
ETHERNET_INTERFACE_REGEX = r"et(?:hernet)?(?P<interface_number>[0-9/]+)"
DEVICE_PREFIX = "eth"
DEVICE_REGEX = DEVICE_PREFIX + r"(?P<device_number>[0-9_]+)"


def interface_to_device_name(interface_name: str) -> str:
    """Map interface name to device name."""
    match_result = re.fullmatch(ETHERNET_INTERFACE_REGEX, interface_name, re.IGNORECASE)
    if match_result is None:
        raise ValueError(f"Invalid interface name: {interface_name}")

    interface_number = match_result.group("interface_number")

    return DEVICE_PREFIX + "_".join(interface_number.split("/"))


def device_to_interface_name(device_name: str) -> str:
    """Map device name to interface name."""
    match_result = re.fullmatch(DEVICE_REGEX, device_name, re.IGNORECASE)
    if match_result is None:
        raise ValueError(f"Invalid device name: {device_name}")

    device_number = match_result.group("device_number")

    return ETHERNET_PREFIX + "/".join(device_number.split("_"))
