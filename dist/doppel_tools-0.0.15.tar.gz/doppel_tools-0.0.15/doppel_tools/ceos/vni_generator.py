"""doppel_tools.eos.vni_generator."""

from doppel_tools.model.topology import Link


class VNIGenerator:
    """VNIGenerator class."""

    def __init__(self, start: int = 10):
        """Constructor."""
        self.current_vni = start
        self.generated_vnis: dict[Link, int] = {}

    def get_next_vni(self) -> int:
        """Get the next vni."""
        next_vni = self.current_vni
        self.current_vni += 1
        return next_vni

    def generate_vni(self, link: Link) -> int:
        """Generate VNI."""
        if link not in self.generated_vnis:
            self.generated_vnis[link] = self.get_next_vni()

        return self.generated_vnis[link]
