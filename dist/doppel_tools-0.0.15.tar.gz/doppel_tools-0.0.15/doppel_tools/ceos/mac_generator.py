"""doppel_tools.eos.mac_generator."""

from hashlib import md5
from typing import Callable

ARISTA_OUI_1 = "00:1c:73"
ARISTA_OUI_2 = "28:e7:1d"


def bytes_from_hex_mac_oui(mac_oui: str) -> bytes:
    """Get bytes from hexadecimal MAC OUI."""
    mac_oui_bytes: bytes = bytes.fromhex(mac_oui.replace(":", ""))
    if len(mac_oui_bytes) != 3:
        raise ValueError("MAC OUI is invalid, should be 3 bytes long")

    return mac_oui_bytes


def md5_hash(data: bytes) -> bytes:
    """Hash data with md5 algorithm."""
    return md5(data, usedforsecurity=False).digest()


class MACGenerator:
    """MACGenerator class."""

    def __init__(self, mac_oui: str, hash_fn: Callable[[bytes], bytes] = md5_hash):
        """Constructor."""
        self.mac_oui_bytes = bytes_from_hex_mac_oui(mac_oui)
        self.hash_fn = hash_fn

    def generate_mac_address(self, seed: bytes) -> str:
        """Generate MAC address."""
        hash_bytes = self.hash_fn(seed)

        mac_bytes = self.mac_oui_bytes + hash_bytes[:3]
        return ":".join([f"{b:02x}" for b in mac_bytes[:6]])
