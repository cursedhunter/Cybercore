"""doppel_tools.topology.split_spread."""

from math import ceil

from doppel_tools.model.topology import Topology
from doppel_tools.topology.split_strategy import HostMap, SplitStrategy
from doppel_tools.utils.chunks import chunks


class SplitSpread(SplitStrategy):
    """Split spread strategy: Spread the nodes in equal chunks into the hosts."""

    def split(self, hosts: list[str], topology: Topology) -> HostMap:
        """Split spread strategy."""
        if len(hosts) == 0:
            raise RuntimeError("Hosts list is empty.")
        if len(topology.nodes) == 0:
            raise RuntimeError("Topology is empty.")

        nodes_per_host = ceil(len(topology.nodes) / len(hosts))
        if nodes_per_host > self.max_nodes_per_host:
            raise RuntimeError(
                f"Can't fit {len(topology.nodes)} nodes into {len(hosts)} "
                f"hosts with max nodes per host={self.max_nodes_per_host}."
            )

        return {host: nodes for host, nodes in zip(hosts, chunks(list(topology.nodes.keys()), nodes_per_host))}
