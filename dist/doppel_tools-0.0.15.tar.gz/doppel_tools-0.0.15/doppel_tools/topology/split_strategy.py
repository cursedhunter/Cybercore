"""doppel_tools.topology.split_strategy."""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Type, TypeAlias

from doppel_tools.model.topology import Topology

HostMap: TypeAlias = dict[str, list[str]]


class SplitStrategy(ABC):
    """SplitStrategy abstract base class."""

    def __init__(self, max_nodes_per_host: int = 40):
        """Split Strategy constructor."""
        self.max_nodes_per_host = max_nodes_per_host

    @abstractmethod
    def split(self, hosts: list[str], topology: Topology) -> HostMap:
        """Split abstract method."""


class SplitStrategyEnum(str, Enum):
    """SplitStrategyEnum."""

    DISJOINT = "disjoint"
    SPREAD = "spread"


def get_split_strategies() -> dict[SplitStrategyEnum, Type[SplitStrategy]]:
    """Initialize register strategies."""
    from doppel_tools.topology.split_disjoint import SplitDisjoint
    from doppel_tools.topology.split_spread import SplitSpread

    return {SplitStrategyEnum.DISJOINT: SplitDisjoint, SplitStrategyEnum.SPREAD: SplitSpread}
