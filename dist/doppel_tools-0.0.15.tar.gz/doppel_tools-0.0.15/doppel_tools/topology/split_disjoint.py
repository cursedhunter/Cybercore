"""doppel_tools.topology.split_disjoint."""

import random
from math import ceil

from doppel_tools.model.topology import Topology
from doppel_tools.topology.split_strategy import HostMap, SplitStrategy
from doppel_tools.utils.chunks import chunks


class SplitDisjoint(SplitStrategy):
    """Split disjoint strategy: Distribute disjoint nodes into the hosts ."""

    def _group_needed_host_count(self, group: list[str]) -> int:
        """Returns the number of hosts needed to accommodate the given group of nodes.

        :param group: A group of nodes.
        :return: An integer of the number of hosts needed to accommodate the given group.
        """
        return ceil(len(group) / self.max_nodes_per_host)

    def _needed_host_count(self, groups: list[list[str]]) -> int:
        """Calculate the total number of needed hosts for a given list of groups.

        :param groups: A list of node groups.
        :return: An integer of the total number of hosts needed to accomodate all groups.
        """
        needed_hosts = 0
        for group in groups:
            needed_hosts += self._group_needed_host_count(group)
        return needed_hosts

    def _group_nodes(self, hosts: list[str], topology: Topology) -> list[list[str]]:
        """Group nodes.

        Group nodes into groups of nodes where the nodes of each group is not
        directly connected to any other node in the group.
        """
        groups: list[list[str]] = []

        ungrouped_nodes = list(topology.nodes.keys())

        while len(ungrouped_nodes) != 0:
            group: list[str] = []

            for node_name in ungrouped_nodes:
                node = topology.nodes[node_name]
                node_peers = set(interface.peer.peer_name for interface in node.physical_interfaces if interface.peer)

                # Append node if peers are not present in group
                if node_peers.isdisjoint(group):
                    group.append(node_name)

            # Filter out selected nodes from pool of ungrouped nodes
            ungrouped_nodes = [node for node in ungrouped_nodes if node not in group]

            groups.append(group)

        if len(hosts) < self._needed_host_count(groups):
            raise RuntimeError(f"{self._needed_host_count(groups)} hosts are needed, but you've only provided {len(hosts)}")

        return groups

    def _assign_hosts(self, groups: list[list[str]], hosts: list[str]) -> HostMap:
        """Assigns hosts to groups of nodes.

        :param groups: A list of node groups.
        :param hosts: A list of hosts.
        :return: A dictionary with the key of host mapping to a value of the list of nodes assigned to each hosts.
        """
        host_mapping: HostMap = {}

        host_index = 0
        for group in groups:
            random.seed(1)  # For deterministic shuffling
            random.shuffle(group)  # Super spines have a lot of links, spread them across the group hosts
            host_count_needed = self._group_needed_host_count(group)
            nodes_per_host = ceil(len(group) / host_count_needed)

            for offset, nodes in enumerate(chunks(group, nodes_per_host)):
                host_mapping[hosts[host_index + offset]] = nodes

            host_index += host_count_needed  # Don't share a host between groups

        return host_mapping

    def split(self, hosts: list[str], topology: Topology) -> HostMap:
        """Split disjoint strategy."""
        if len(hosts) == 0:
            raise RuntimeError("Hosts list is empty.")
        if len(topology.nodes) == 0:
            raise RuntimeError("Topology is empty.")

        groups = self._group_nodes(hosts, topology)
        return self._assign_hosts(groups, hosts)
