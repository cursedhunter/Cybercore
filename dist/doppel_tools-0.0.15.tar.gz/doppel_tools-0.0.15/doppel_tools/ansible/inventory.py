"""Inventory module wrapping Ansible Inventory Manager."""

from pathlib import Path

from ansible.inventory.host import Host  # type: ignore
from ansible.inventory.manager import InventoryManager  # type: ignore
from ansible.parsing.dataloader import DataLoader  # type: ignore
from ansible.plugins.loader import init_plugin_loader  # type: ignore
from ansible.vars.manager import VariableManager  # type: ignore

init_plugin_loader()


class Inventory:  # pylint: disable=too-few-public-methods
    """Ansible Inventory wrapper."""

    def __init__(self, inventory_path: Path, data_loader: DataLoader = DataLoader()) -> None:
        """Initialize Ansible Inventory Manager."""
        self.inventory_path = inventory_path
        self.data_loader = data_loader
        self.inventory_manager = InventoryManager(loader=self.data_loader, sources=[self.inventory_path.as_posix()], parse=True)
        self.variable_manager = VariableManager(loader=self.data_loader, inventory=self.inventory_manager)

    def get_hosts(self, pattern: str, order: str = "sorted") -> list[Host]:
        """Takes a pattern or list of patterns and returns a list of matching inventory host."""
        return self.inventory_manager.get_hosts(pattern=pattern, order=order)

    def get_vars(self, host: Host) -> dict:
        """Get host vars."""
        return self.variable_manager.get_vars(host=host)
